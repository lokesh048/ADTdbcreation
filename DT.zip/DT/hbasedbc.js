const HBase = require('hbase-client'); 
// Import the HBase client library.

const config = {
    zookeeperHosts: ["localhost"], 
    // Define the Zookeeper hosts for HBase.

    zookeeperRoot: "/hbase", 
    // Specify the Zookeeper root path for HBase.

    rpcTimeout: 30000, 
    // Timeout for RPC (Remote Procedure Call) operations.

    callTimeout: 30000, 
    reconnectTimeout: 30000 
    // Timeout for reconnecting to the server.
};

const client = HBase.create(config); 
// Create a connection to the HBase server with the specified configuration.

async function createTable() {
    const tableDescriptor = {
        name: "MyHBaseTable", 
        // Define the name of the table.

        families: [{ name: "data" }] 
        // Specify a column family named 'data'.
    };

    try {
        await client.createTable(tableDescriptor); 
        // Call the createTable method with the table descriptor.

        console.log("Table created: MyHBaseTable"); 
        // Log a success message if the table is created.
    } catch (err) {
        console.error("Error creating table:", err); 
        // Log any errors encountered during table creation.
    } finally {
        client.close(); 
        // Close the HBase client connection.
    }
}

createTable(); 
// Invoke the function to execute the table creation logic.
