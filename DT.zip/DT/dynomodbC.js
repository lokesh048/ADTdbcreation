const AWS = require('aws-sdk'); 
// Import the AWS SDK library for interacting with AWS services. 
AWS.config.update({ 
region: "us-east-1", 
// Specify the AWS region where DynamoDB is running. 
endpoint: "http://localhost:8000" 
// Use the local DynamoDB instance endpoint. 
}); 
const dynamoDB = new AWS.DynamoDB(); 
// Create a DynamoDB service object. 
const params = { 
TableName: "MyDynamoDBTable", 
// Name of the table to be created. 
KeySchema: [ 
{ AttributeName: "id", KeyType: "HASH" } 
// Define the primary key schema. 'id' is the partition key. 
], 
AttributeDefinitions: [ 
{ AttributeName: "id", AttributeType: "S" } 
// Define the data type of the 'id' attribute as a string. 
], 
ProvisionedThroughput: { 
ReadCapacityUnits: 1, 
// Set the read capacity units for the table. 
WriteCapacityUnits: 1 
// Set the write capacity units for the table. 
} 
}; 
dynamoDB.createTable(params, (err, data) => { 
// Call the `createTable` method to create the table using the defined parameters. 
if (err) { 
console.error("Error creating table:", JSON.stringify(err, null, 2)); 
// Log an error message if table creation fails. 
} else { 
console.log("Table created:", JSON.stringify(data, null, 2)); 
// Log the success message with table details. 
} 
}); 
