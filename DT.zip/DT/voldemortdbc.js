const fetch = require('node-fetch'); 
// Import the 'node-fetch' library for making HTTP requests.

async function createStore() {
    const url = "http://localhost:8080/stores"; 
    // Endpoint for managing Voldemort stores.

    const storeConfig = `
    <store>
        <name>MyVoldemortStore</name> 
        <!-- Name of the key-value store being created -->

        <key-serializer>
            <type>string</type> 
            <!-- Specify that the keys are serialized as strings -->
        </key-serializer>

        <value-serializer>
            <type>string</type> 
            <!-- Specify that the values are serialized as strings -->
        </value-serializer>
    </store>`;

    try {
        const response = await fetch(url, {
            method: "POST", 
            // Use POST method to send the store creation request.

            headers: { "Content-Type": "application/xml" }, 
            // Specify that the request body is in XML format.

            body: storeConfig 
            // Send the store configuration as the request body.
        });

        if (response.ok) {
            console.log("Store created successfully"); 
            // Log a success message if the store is created.
        } else {
            console.error("Error creating store:", response.statusText); 
            // Log the response's error status if store creation fails.
        }
    } catch (err) {
        console.error("Request failed:", err); 
        // Handle and log network or other errors.
    }
}

createStore(); 
// Invoke the function to create the store.
