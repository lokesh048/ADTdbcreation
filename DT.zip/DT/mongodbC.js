const { MongoClient } = require('mongodb'); 
// Import the MongoClient class from the 'mongodb' library.

async function createDatabase() {
    const uri = "mongodb://127.0.0.1:27017"; 
    // Connection string to connect to the MongoDB server running locally.

    const client = new MongoClient(uri); 
    // Create a new MongoClient instance to connect to the server.

    try {
        await client.connect(); 
        // Connect to the MongoDB server.

        console.log("Connected to MongoDB"); 
        // Log a success message.

        const db = client.db("MyMongoDB"); 
        // Create a database named 'MyMongoDB'. If it doesn't exist, MongoDB will create it when data is added.

        console.log("Database created: MyMongoDB"); 
        // Log that the database has been created.
    } catch (err) {
        console.error(err); 
        // Handle and log any errors that occur during the connection or database creation process.
    } finally {
        await client.close(); 
        // Close the connection to the MongoDB server to free up resources.
    }
}

createDatabase(); 
// Invoke the function to execute the database creation logic.
