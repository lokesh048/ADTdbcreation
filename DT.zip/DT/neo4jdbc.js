const neo4j = require('neo4j-driver'); 
// Import the Neo4j driver library for Node.js.

const driver = neo4j.driver("bolt://localhost:7687", neo4j.auth.basic("neo4j", "password")); 
// Create a driver instance to connect to the Neo4j database. Replace 'password' with your actual password.

const session = driver.session(); 
// Open a new session to interact with the database.

async function createDatabase() {
    try {
        await session.run('CREATE (n:Database {name: "MyNeo4jDB"}) RETURN n'); 
        // Execute a Cypher query to create a node with the label 'Database' and a property 'name'.

        console.log("Database node created: MyNeo4jDB"); 
        // Log a success message when the node is created.
    } catch (err) {
        console.error("Error creating database:", err); 
        // Log any errors encountered during the database creation process.
    } finally {
        await session.close(); 
        // Close the session.

        await driver.close(); 
        // Close the driver to free resources.
    }
}

createDatabase(); 
// Invoke the function to execute the database creation logic.
